import Metal
import MetalKit

class Renderer: NSObject, MTKViewDelegate {
    
    public let device: MTLDevice
    let commandQueue: MTLCommandQueue
    
    // sets the information for the draw (shader functions, color depth) and how to read vertex data
    let renderPipeline: MTLRenderPipelineState
    
    var colorMap: MTLTexture

    let vertexData: [Vertex] = [
        Vertex(position: [-1.0, 1.0], texcoord: [0.0, 1.0]),   // Top left
        Vertex(position: [-1.0, -1.0], texcoord: [0.0, 0.0]),  // Bottom left
        Vertex(position: [1.0, -1.0], texcoord: [1.0, 0.0]),   // Bottom right
        Vertex(position: [1.0, 1.0], texcoord: [1.0, 1.0]),    // Top right
        Vertex(position: [-1.0, 1.0], texcoord: [0.0, 1.0]),   // Top left
        Vertex(position: [1.0, -1.0], texcoord: [1.0, 0.0])    // Bottom right
    ]
    let vertexBuffer: MTLBuffer
    
    var viewportSize: vector_uint2
    
    init?(metalKitView: MTKView) {
        guard
            let device = MTLCreateSystemDefaultDevice(),
            let commandQueue = device.makeCommandQueue() else {
            return nil
        }
        self.device = device
        self.commandQueue = commandQueue
        self.viewportSize = .zero

        metalKitView.device = device
        
        let vertexDescriptor = Renderer.buildVertexDescriptor()
        do {
            self.renderPipeline = try Renderer.buildRenderPipeline(
                device: device,
                mtkView: metalKitView,
                vertexDescriptor: vertexDescriptor
            )
        } catch {
            fatalError("Unable to compile render pipeline state.")
            return nil
        }
        
        // Create a triangle
        self.vertexBuffer = device.makeBuffer(bytes: vertexData,
                                              length: vertexData.count * MemoryLayout<Vertex>.size,
                                              options: [])!

        // create texture
        let width = 640
        let height = 640
        
        let textureDescriptor = MTLTextureDescriptor()
        textureDescriptor.pixelFormat = .rgba8Unorm
        textureDescriptor.width = width
        textureDescriptor.height = height
        guard let texture = device.makeTexture(descriptor: textureDescriptor) else { return nil }
        colorMap = texture
        
        // === write to the texture ===
        let region = MTLRegionMake2D(0, 0, width, height)
        let mipmapLevel = 0
        let bytesPerRow = width * 4 // RGBA8 format

        // create a data to fill into the texture
        var rawData = [UInt8](repeating: 0, count: width * height * 4)
        // fill with XOR pattern
        for y in 0..<height {
            for x in 0..<width {
                let index = (y * width + x) * 4
                let xorValue = UInt8((x ^ y) & 255) // XOR op, clamped to 8 bits
                
                rawData[index] = xorValue // red
                rawData[index + 1] = xorValue // green
                rawData[index + 2] = xorValue // blue
                rawData[index + 3] = 255 // alpha
            }
        }

        // move data into texture memory
        texture.replace(region: region,
                        mipmapLevel: mipmapLevel,
                        withBytes: rawData,
                        bytesPerRow: bytesPerRow)
        // ============================
        
        super.init()
        metalKitView.delegate = self
    }
    
    private static func buildVertexDescriptor() -> MTLVertexDescriptor {
        let vertexDescriptor = MTLVertexDescriptor()
        
        // vertexShader [[stage_in]]
        
        // Vertex attribute: [x, y, u, v] - combined
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].format = MTLVertexFormat.float2
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].offset = 0
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].bufferIndex = BufferIndex.vertexData.rawValue
        
        vertexDescriptor.attributes[VertexAttribute.texcoord.rawValue].format = MTLVertexFormat.float2
        vertexDescriptor.attributes[VertexAttribute.texcoord.rawValue].offset = 2 * MemoryLayout<Float>.size
        vertexDescriptor.attributes[VertexAttribute.texcoord.rawValue].bufferIndex = BufferIndex.vertexData.rawValue

        // Set up layout (total stride of 16 bytes = 4 floats * 4 bytes each)
        vertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stride = 16
        vertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stepRate = 1
        vertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stepFunction = MTLVertexStepFunction.perVertex

        return vertexDescriptor
    }
    
    private static func buildRenderPipeline(
        device: MTLDevice,
        mtkView: MTKView,
        vertexDescriptor: MTLVertexDescriptor
    ) throws -> MTLRenderPipelineState  {
        let pipelineDescriptor = MTLRenderPipelineDescriptor()
        pipelineDescriptor.label = "RenderPipeline"

        // add shaders to pipeline
        let library = device.makeDefaultLibrary()
        pipelineDescriptor.vertexFunction = library?.makeFunction(name: "vertexShader")
        pipelineDescriptor.fragmentFunction = library?.makeFunction(name: "fragmentShader")
        
        // vertex descriptor
        pipelineDescriptor.vertexDescriptor = vertexDescriptor

        // set the output pixel format to match the pixel format of the metal kit view
        pipelineDescriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat
        
        // compile the configured pipeline descriptor
        return try device.makeRenderPipelineState(descriptor: pipelineDescriptor)
    }
    
    func draw(in view: MTKView) {
        guard
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let renderPassDescriptor = view.currentRenderPassDescriptor,
            let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor)
        else {
            return
        }
        
        renderEncoder.setRenderPipelineState(renderPipeline)
        
        // Set the region of the drawable to draw into.
        renderEncoder.setViewport(MTLViewport(originX: 0.0, originY: 0.0, width: Double(viewportSize.x), height: Double(viewportSize.y), znear: -1.0, zfar: 1.0))

        renderEncoder.setVertexBuffer(vertexBuffer, offset: 0, index: BufferIndex.vertexData.rawValue)
        renderEncoder.setVertexBytes(&viewportSize, length: MemoryLayout<simd_uint2>.size, index: BufferIndex.viewportSize.rawValue)
        
        renderEncoder.setFragmentTexture(colorMap, index: TextureIndex.color.rawValue)
        renderEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: vertexData.count)
        renderEncoder.endEncoding()
        
        if let drawable = view.currentDrawable {
            commandBuffer.present(drawable)
        }
        
        commandBuffer.commit()
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        viewportSize.x = UInt32(size.width)
        viewportSize.y = UInt32(size.height)
    }
}
