import Metal
import MetalKit

class Renderer: NSObject, MTKViewDelegate {
    
    // reference to GPU hardware
    let device: MTLDevice

    // responsible for creating and organizing MTLCommandBuffers each frame (submitting to GPU)
    let commandQueue: MTLCommandQueue
    
    // sets the information for the draw (shader functions, color depth) and how to read vertex data
    let renderPipeline: MTLRenderPipelineState
    
   var colorMap: MTLTexture

    let vertexData: [Float] = [
        -0.5,  0.5, 0.0, 1.0,  // Vertex 1: x, y, u, v (top left)
        -0.5, -0.5, 0.0, 0.0,  // Vertex 2: x, y, u, v (bottom left) 
         0.5, -0.5, 1.0, 0.0,  // Vertex 3: x, y, u, v (bottom right)
         0.5,  0.5, 1.0, 1.0,  // Vertex 4: x, y, u, v (top right)
        -0.5,  0.5, 0.0, 1.0,  // Vertex 5: x, y, u, v (top left)
         0.5, -0.5, 1.0, 0.0   // Vertex 6: x, y, u, v (bottom right)
    ]
    let vertexBuffer: MTLBuffer

    init?(metalView: MTKView) {
        guard
            let device = MTLCreateSystemDefaultDevice(),
            let commandQueue = device.makeCommandQueue() else {
            return nil
        }
        self.device = device
        self.commandQueue = commandQueue
        
        metalView.device = device
        
        let vertexDescriptor = Renderer.buildVertexDescriptor()
        do {
            self.renderPipeline = try Renderer.buildRenderPipeline(
                device: device,
                mtkView: metalView,
                vertexDescriptor: vertexDescriptor
            )
        } catch {
            fatalError("Unable to compile render pipeline state.")
            return nil
        }
        
        // Create a triangle
        self.vertexBuffer = device.makeBuffer(bytes: vertexData,
                                              length: vertexData.count * MemoryLayout<Float>.size,
                                              options: [])!

        do {
            colorMap = try Renderer.loadTexture(device: device, textureName: "UVTest")
        } catch {
            print("Unable to load texture. Error info: \(error)")
            return nil
        }
        
        super.init()
        
        metalView.delegate = self
    }
    
    private static func buildVertexDescriptor() -> MTLVertexDescriptor {
        let vertexDescriptor = MTLVertexDescriptor()
        
        // vertexShader [[stage_in]]
        
        // Vertex attribute: [x, y, u, v] - combined
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].format = MTLVertexFormat.float2
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].offset = 0
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].bufferIndex = BufferIndex.meshPositions.rawValue
        
        vertexDescriptor.attributes[VertexAttribute.texcoord.rawValue].format = MTLVertexFormat.float2
        vertexDescriptor.attributes[VertexAttribute.texcoord.rawValue].offset = 2 * MemoryLayout<Float>.size
        vertexDescriptor.attributes[VertexAttribute.texcoord.rawValue].bufferIndex = BufferIndex.meshPositions.rawValue

        // Set up layout (total stride of 16 bytes = 4 floats * 4 bytes each)
        vertexDescriptor.layouts[BufferIndex.meshPositions.rawValue].stride = 16
        vertexDescriptor.layouts[BufferIndex.meshPositions.rawValue].stepRate = 1
        vertexDescriptor.layouts[BufferIndex.meshPositions.rawValue].stepFunction = MTLVertexStepFunction.perVertex

        return vertexDescriptor
    }
    
    private static func buildRenderPipeline(
        device: MTLDevice,
        mtkView: MTKView,
        vertexDescriptor: MTLVertexDescriptor
    ) throws -> MTLRenderPipelineState  {
        let pipelineDescriptor = MTLRenderPipelineDescriptor()
        pipelineDescriptor.label = "RenderPipeline"

        // add shaders to pipeline
        let library = device.makeDefaultLibrary()
        pipelineDescriptor.vertexFunction = library?.makeFunction(name: "vertexShader")
        pipelineDescriptor.fragmentFunction = library?.makeFunction(name: "fragmentShader")
        
        // vertex descriptor
        pipelineDescriptor.vertexDescriptor = vertexDescriptor

        // set the output pixel format to match the pixel format of the metal kit view
        pipelineDescriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat
        
        // compile the configured pipeline descriptor
        return try device.makeRenderPipelineState(descriptor: pipelineDescriptor)
    }

    class func loadTexture(device: MTLDevice,
                           textureName: String) throws -> MTLTexture {
        /// Load texture data with optimal parameters for sampling
        
        let textureLoader = MTKTextureLoader(device: device)

        let textureLoaderOptions = [
            MTKTextureLoader.Option.textureUsage: NSNumber(value: MTLTextureUsage.shaderRead.rawValue),
            MTKTextureLoader.Option.textureStorageMode: NSNumber(value: MTLStorageMode.`private`.rawValue)
        ]

        return try textureLoader.newTexture(name: textureName,
                                            scaleFactor: 1.0,
                                            bundle: nil,
                                            options: textureLoaderOptions)
    }

    func draw(in view: MTKView) {
        guard
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let renderPassDescriptor = view.currentRenderPassDescriptor,
            let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor)
        else {
            return
        }
        
        renderEncoder.setRenderPipelineState(renderPipeline)
        renderEncoder.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
        renderEncoder.setFragmentTexture(colorMap, index: TextureIndex.color.rawValue)
        renderEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: vertexData.count)
        renderEncoder.endEncoding()
        
        if let drawable = view.currentDrawable {
            commandBuffer.present(drawable)
        }
        
        commandBuffer.commit()
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) { }
}
