import Metal
import MetalKit
import simd

class Renderer: NSObject, MTKViewDelegate {
    
    let device: MTLDevice
    let commandQueue: MTLCommandQueue
    
    // texture memory destination for first rendering pass
    var renderTargetTexture: MTLTexture
    
    // render pass to draw to the offscreen texture
    let renderToOffscreenTextureRenderPassDescriptor: MTLRenderPassDescriptor
    
    // a pipeline to render to the offscreen texture
    let offscreenRenderPipeline: MTLRenderPipelineState

    // a pipeline to render to the screen
    let drawableRenderPipeline: MTLRenderPipelineState
    
    // first pass draws a triangle
    let triangleVertexData: [Vertex] = [
        Vertex(position: [0.0, 0.5], color: [1.0, 0.0, 0.0, 1.0]),
        Vertex(position: [-0.5, -0.5], color: [0.0, 1.0, 0.0, 1.0]),
        Vertex(position: [0.5, -0.5], color: [0.0, 0.0, 1.0, 1.0])
    ]
    let triangleVertexBuffer: MTLBuffer
    
    init?(metalKitView: MTKView) {
        self.device = metalKitView.device!
        guard let commandQueue = device.makeCommandQueue() else { return nil }
        self.commandQueue = commandQueue
        
        metalKitView.clearColor = MTLClearColorMake(1.0, 0.0, 0.0, 1.0)
        
        // create a vertex buffer with triangle data
        self.triangleVertexBuffer = device.makeBuffer(bytes: triangleVertexData,
                                              length: triangleVertexData.count * MemoryLayout<Vertex>.size,
                                              options: [])!
        
        // 1) Offscreen texture destination to render to
        let texDesciptor = MTLTextureDescriptor()
        texDesciptor.textureType = .type2D
        texDesciptor.width = 512
        texDesciptor.height = 512
        texDesciptor.pixelFormat = .rgba8Unorm
        texDesciptor.usage = [.renderTarget, .shaderRead]
        guard let texture = device.makeTexture(descriptor: texDesciptor) else { return nil }
        renderTargetTexture = texture
        
        // 2) Create a render pass targeting the offscreen texture
        renderToOffscreenTextureRenderPassDescriptor = MTLRenderPassDescriptor()
        renderToOffscreenTextureRenderPassDescriptor.colorAttachments[0].texture = renderTargetTexture
        renderToOffscreenTextureRenderPassDescriptor.colorAttachments[0].loadAction = .clear
        renderToOffscreenTextureRenderPassDescriptor.colorAttachments[0].clearColor = MTLClearColorMake(1, 1, 1, 1)
        renderToOffscreenTextureRenderPassDescriptor.colorAttachments[0].storeAction = .store

        let library = device.makeDefaultLibrary()
        // 3) First render pipeline: renders to offscreen texture
        var pipelineDescriptor = MTLRenderPipelineDescriptor()
        pipelineDescriptor.label = "Offscreen Render Pipeline"
        pipelineDescriptor.rasterSampleCount = 1
        pipelineDescriptor.vertexFunction = library?.makeFunction(name: "vertexShader")
        pipelineDescriptor.fragmentFunction = library?.makeFunction(name: "fragmentShader")
        pipelineDescriptor.vertexDescriptor = Self.buildMetalVertexDescriptor()
        pipelineDescriptor.colorAttachments[0].pixelFormat = renderTargetTexture.pixelFormat
        do {
            offscreenRenderPipeline = try device.makeRenderPipelineState(descriptor: pipelineDescriptor)
        } catch {
            print("Failed to create pipeline state to render to texture: \(error)")
            return nil
        }
        
        // 4) Final render pipeline: renders to screen
        pipelineDescriptor = MTLRenderPipelineDescriptor()
        pipelineDescriptor.label = "Drawable Render Pipeline"
        pipelineDescriptor.rasterSampleCount = metalKitView.sampleCount
        pipelineDescriptor.vertexFunction = library?.makeFunction(name: "vertexDisplayShader")
        pipelineDescriptor.fragmentFunction = library?.makeFunction(name: "fragmentDisplayShader")
        // doesn't use a vertex descriptor
        pipelineDescriptor.colorAttachments[0].pixelFormat = metalKitView.colorPixelFormat
        do {
            drawableRenderPipeline = try device.makeRenderPipelineState(descriptor: pipelineDescriptor)
        } catch {
            print("Failed to create pipeline state to render to screen: \(error)")
            return nil
        }

        super.init()
    }
    
    class func buildMetalVertexDescriptor() -> MTLVertexDescriptor {
        let mtlVertexDescriptor = MTLVertexDescriptor()
        
        mtlVertexDescriptor.attributes[VertexAttribute.position.rawValue].format = MTLVertexFormat.float2
        mtlVertexDescriptor.attributes[VertexAttribute.position.rawValue].offset = 0
        mtlVertexDescriptor.attributes[VertexAttribute.position.rawValue].bufferIndex = BufferIndex.vertexData.rawValue
        
        mtlVertexDescriptor.attributes[VertexAttribute.color.rawValue].format = MTLVertexFormat.float4
        mtlVertexDescriptor.attributes[VertexAttribute.color.rawValue].offset = 8 // 2 floats
        mtlVertexDescriptor.attributes[VertexAttribute.color.rawValue].bufferIndex = BufferIndex.vertexData.rawValue
        
        mtlVertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stride = 24 // 2 + 4 * 4 = 24
        mtlVertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stepRate = 1
        mtlVertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stepFunction = MTLVertexStepFunction.perVertex
        
        return mtlVertexDescriptor
    }
    
    func draw(in view: MTKView) {
        guard let commandBuffer = commandQueue.makeCommandBuffer() else {
            return
        }
        
        // 1) Render to offscreen texture
        if let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderToOffscreenTextureRenderPassDescriptor) {
            renderEncoder.label = "Offscreen Render Pass"
            renderEncoder.pushDebugGroup("Offscreen Pass")
            renderEncoder.setRenderPipelineState(offscreenRenderPipeline)
            
            renderEncoder.setVertexBuffer(triangleVertexBuffer, offset: 0, index: BufferIndex.vertexData.rawValue)
            renderEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
            
            renderEncoder.popDebugGroup()
            renderEncoder.endEncoding()
        }
        
        // 2) Render to screen
        if let renderPassDescriptor = view.currentRenderPassDescriptor,
        let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor) {
            renderEncoder.label = "Drawable Render Pass"
            renderEncoder.pushDebugGroup("Draw Pass")
            renderEncoder.setRenderPipelineState(drawableRenderPipeline)
            
            // vertex data
            let quadVertices: [TextureVertex] = [
                // Positions     , Texture coordinates
                TextureVertex(position: [0.5, -0.5], texcoord: [1.0, 1.0]),
                TextureVertex(position: [-0.5, -0.5], texcoord: [0.0, 1.0]),
                TextureVertex(position: [-0.5, 0.5], texcoord: [0.0, 0.0]),
                
                TextureVertex(position: [0.5, -0.5], texcoord: [1.0, 1.0]), 
                TextureVertex(position: [-0.5, 0.5], texcoord: [0.0, 0.0]),
                TextureVertex(position: [0.5, 0.5], texcoord: [1.0, 0.0])
            ]
            
            renderEncoder.setVertexBytes(quadVertices, 
                                       length: MemoryLayout<TextureVertex>.stride * quadVertices.count,
                                       index: BufferIndex.vertexData.rawValue)
            
            // texture binding
            renderEncoder.setFragmentTexture(renderTargetTexture, index: TextureIndex.color.rawValue)

            renderEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 6)
            renderEncoder.popDebugGroup()
            renderEncoder.endEncoding()
            
            // display!
            if let drawable = view.currentDrawable {
                commandBuffer.present(drawable)
            }
        }
        
        commandBuffer.commit()
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
    }
}
