import Metal
import MetalKit

class Renderer: NSObject, MTKViewDelegate {
    
    // reference to GPU hardware
    let device: MTLDevice

    // responsible for creating and organizing MTLCommandBuffers each frame (submitting to GPU)
    let commandQueue: MTLCommandQueue
    
    // sets the information for the draw (shader functions, color depth) and how to read vertex data
    let renderPipeline: MTLRenderPipelineState
    
    let vertexData: [Vertex] = [
        Vertex(position: [0.0, 0.5], color: [1.0, 0.0, 0.0, 1.0]),
        Vertex(position: [-0.5, -0.5], color: [0.0, 1.0, 0.0, 1.0]), 
        Vertex(position: [0.5, -0.5], color: [0.0, 0.0, 1.0, 1.0])
    ]
    let vertexBuffer: MTLBuffer

    init?(metalView: MTKView) {
        guard
            let device = MTLCreateSystemDefaultDevice(),
            let commandQueue = device.makeCommandQueue() else {
            return nil
        }
        self.device = device
        self.commandQueue = commandQueue
        
        metalView.device = device
        
        let vertexDescriptor = Renderer.buildVertexDescriptor()
        do {
            self.renderPipeline = try Renderer.buildRenderPipeline(
                device: device,
                mtkView: metalView,
                vertexDescriptor: vertexDescriptor
            )
        } catch {
            fatalError("Unable to compile render pipeline state.")
            return nil
        }
        
        // create a vertex buffer with triangle data
        self.vertexBuffer = device.makeBuffer(bytes: vertexData,
                                              length: vertexData.count * MemoryLayout<Vertex>.size,
                                              options: [])!

        super.init()
        
        metalView.delegate = self
    }
    
    private static func buildVertexDescriptor() -> MTLVertexDescriptor {
        let vertexDescriptor = MTLVertexDescriptor()
        
        // vertexShader [[stage_in]]
        
        // Set up position attribute (only x, y)
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].format = MTLVertexFormat.float2
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].offset = 0
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].bufferIndex = BufferIndex.vertexData.rawValue
        
        vertexDescriptor.attributes[VertexAttribute.color.rawValue].format = MTLVertexFormat.float4
        vertexDescriptor.attributes[VertexAttribute.color.rawValue].offset = 8 // 2 floats * 4 bytes = 8 bytes
        vertexDescriptor.attributes[VertexAttribute.color.rawValue].bufferIndex = BufferIndex.vertexData.rawValue

        // Set up layout (total stride of 24 bytes = 2 floats + 4 floats * 4 bytes each)
        vertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stride = 24
        vertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stepRate = 1
        vertexDescriptor.layouts[BufferIndex.vertexData.rawValue].stepFunction = MTLVertexStepFunction.perVertex

        return vertexDescriptor
    }
    
    private static func buildRenderPipeline(
        device: MTLDevice,
        mtkView: MTKView,
        vertexDescriptor: MTLVertexDescriptor
    ) throws -> MTLRenderPipelineState  {
        let pipelineDescriptor = MTLRenderPipelineDescriptor()
        pipelineDescriptor.label = "RenderPipeline"

        // add shaders to pipeline
        let library = device.makeDefaultLibrary()
        pipelineDescriptor.vertexFunction = library?.makeFunction(name: "vertexShader")
        pipelineDescriptor.fragmentFunction = library?.makeFunction(name: "fragmentShader")
        
        // vertex descriptor
        pipelineDescriptor.vertexDescriptor = vertexDescriptor

        // set the output pixel format to match the pixel format of the metal kit view
        pipelineDescriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat
        
        // compile the configured pipeline descriptor
        return try device.makeRenderPipelineState(descriptor: pipelineDescriptor)
    }

    func draw(in view: MTKView) {
        guard
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let renderPassDescriptor = view.currentRenderPassDescriptor,
            let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor)
        else {
            return
        }
        
        renderEncoder.setRenderPipelineState(renderPipeline)
        renderEncoder.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
        renderEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        renderEncoder.endEncoding()
        
        if let drawable = view.currentDrawable {
            commandBuffer.present(drawable)
        }
        
        commandBuffer.commit()
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
    }
}
