import Metal
import MetalKit

class Renderer: NSObject, MTKViewDelegate {
    
    // reference to GPU hardware
    let device: MTLDevice

    // responsible for creating and organizing MTLCommandBuffers each frame (submitting to GPU)
    let commandQueue: MTLCommandQueue
    
    // sets the information for the draw (shader functions, color depth) and how to read vertex data
    let renderPipeline: MTLRenderPipelineState
    
    let vertexData: [Float] = [
        0.0,  0.5, 1.0, 0.0, 0.0,   // Vertex 1: x, y, r, g, b
        -0.5, -0.5, 0.0, 1.0, 0.0,  // Vertex 2: x, y, r, g, b
        0.5, -0.5, 0.0, 0.0, 1.0    // Vertex 3: x, y, r, g, b
    ]
    let vertexBuffer: MTLBuffer

    let uniformsBuffer: MTLBuffer
    var uniforms: Uniforms
    var lastFrameTime: CFTimeInterval

    init?(metalView: MTKView) {
        guard
            let device = MTLCreateSystemDefaultDevice(),
            let commandQueue = device.makeCommandQueue() else {
            return nil
        }
        self.device = device
        self.commandQueue = commandQueue
        
        metalView.device = device
        
        let vertexDescriptor = Renderer.buildVertexDescriptor()
        do {
            self.renderPipeline = try Renderer.buildRenderPipeline(
                device: device,
                mtkView: metalView,
                vertexDescriptor: vertexDescriptor
            )
        } catch {
            fatalError("Unable to compile render pipeline state.")
            return nil
        }
        
        // Create a triangle
        self.vertexBuffer = device.makeBuffer(bytes: vertexData,
                                              length: vertexData.count * MemoryLayout<Float>.size,
                                              options: [])!

        // Initialize uniforms
        self.uniforms = Uniforms(
            offset: SIMD2<Float>(0, 0),
            time: 0.0
        )
        
        // Create a buffer that will hold our uniforms
        guard let uniformsBuffer = device.makeBuffer(
            length: MemoryLayout<Uniforms>.size,
            options: [.storageModeShared]
        ) else {
            return nil
        }
        self.uniformsBuffer = uniformsBuffer
        self.lastFrameTime = CFAbsoluteTimeGetCurrent()

        super.init()
        
        metalView.delegate = self
    }
    
    private static func buildVertexDescriptor() -> MTLVertexDescriptor {
        let vertexDescriptor = MTLVertexDescriptor()
        
        // vertexShader [[stage_in]]
        
        // Set up position attribute (only x, y)
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].format = MTLVertexFormat.float2
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].offset = 0
        vertexDescriptor.attributes[VertexAttribute.position.rawValue].bufferIndex = BufferIndex.meshPositions.rawValue
        
        vertexDescriptor.attributes[VertexAttribute.color.rawValue].format = MTLVertexFormat.float3
        vertexDescriptor.attributes[VertexAttribute.color.rawValue].offset = 8 // bytes
        vertexDescriptor.attributes[VertexAttribute.color.rawValue].bufferIndex = BufferIndex.meshPositions.rawValue

        // Set up layout (total stride of 8 bytes = 2 floats * 4 bytes each)
        vertexDescriptor.layouts[BufferIndex.meshPositions.rawValue].stride = 20 // 2 + 3 * 4 bytes = 20 bytes
        vertexDescriptor.layouts[BufferIndex.meshPositions.rawValue].stepRate = 1
        vertexDescriptor.layouts[BufferIndex.meshPositions.rawValue].stepFunction = MTLVertexStepFunction.perVertex

        return vertexDescriptor
    }
    
    private static func buildRenderPipeline(
        device: MTLDevice,
        mtkView: MTKView,
        vertexDescriptor: MTLVertexDescriptor
    ) throws -> MTLRenderPipelineState  {
        let pipelineDescriptor = MTLRenderPipelineDescriptor()
        pipelineDescriptor.label = "RenderPipeline"

        // add shaders to pipeline
        let library = device.makeDefaultLibrary()
        pipelineDescriptor.vertexFunction = library?.makeFunction(name: "vertexShader")
        pipelineDescriptor.fragmentFunction = library?.makeFunction(name: "fragmentShader")
        
        // vertex descriptor
        pipelineDescriptor.vertexDescriptor = vertexDescriptor

        // set the output pixel format to match the pixel format of the metal kit view
        pipelineDescriptor.colorAttachments[0].pixelFormat = mtkView.colorPixelFormat
        
        // compile the configured pipeline descriptor
        return try device.makeRenderPipelineState(descriptor: pipelineDescriptor)
    }

    private func updateUniforms() {
        let currentTime = CFAbsoluteTimeGetCurrent()
        let deltaTime = Float(currentTime - lastFrameTime)
        lastFrameTime = currentTime
        
        // Update time
        uniforms.time += deltaTime
        
        // Update offset
        uniforms.offset = SIMD2<Float>(sin(uniforms.time * 1.2), cos(uniforms.time))
        
        // Copy uniforms struct to buffer
        let bufferPointer = uniformsBuffer.contents().assumingMemoryBound(to: Uniforms.self)
        bufferPointer.pointee = uniforms
    }

    func draw(in view: MTKView) {
        guard
            let commandBuffer = commandQueue.makeCommandBuffer(),
            let renderPassDescriptor = view.currentRenderPassDescriptor,
            let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor)
        else {
            return
        }
        
        updateUniforms()
        
        renderEncoder.setRenderPipelineState(renderPipeline)
        
        renderEncoder.setVertexBuffer(uniformsBuffer, offset: 0, index: BufferIndex.uniforms.rawValue)
        renderEncoder.setFragmentBuffer(uniformsBuffer, offset: 0, index: BufferIndex.uniforms.rawValue)
        
        renderEncoder.setVertexBuffer(vertexBuffer, offset: 0, index: 0)
        renderEncoder.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
        
        renderEncoder.endEncoding()
        
        if let drawable = view.currentDrawable {
            commandBuffer.present(drawable)
        }
        
        commandBuffer.commit()
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
    }
}
