//
//  SimpleMetalRendererApp.swift
//  SimpleMetalRenderer
//
//  Created by Kyle Stewart on 4/11/22.
//

import SwiftUI

@main
struct SimpleMetalRendererApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
