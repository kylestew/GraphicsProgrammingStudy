# SimpleMetalRenderer

Sandbox project to understand the basics of Metal
