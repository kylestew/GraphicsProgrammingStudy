import Cocoa
import MetalKit

class GameViewController: NSViewController {

    var mtkView: MTKView!
    var renderer: Renderer!

    override func viewDidLoad() {
        super.viewDidLoad()

        guard let mtkView = self.view as? MTKView else {
            print("View attached to GameViewController is not an MTKView")
            return
        }
        
        guard let renderer = Renderer(metalView: mtkView) else {
            fatalError("Cannot create Renderer")
        }
        self.renderer = renderer
//        renderer.mtkView(mtkView, drawableSizeWillChange: mtkView.drawableSize)
    }
}
