from .vec3 import Vec3

Color = Vec3

__all__ = ["Vec3", "Color"]
